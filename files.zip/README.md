# Neon Swarm

Survivor de arena em neon feito do zero com **JavaScript puro e Canvas 2D**, sem engine e sem dependências. Você sobrevive a hordas cada vez maiores, escolhe upgrades a cada nível e enfrenta chefes.

**Jogar online:** https://lauradeola.github.io/neon-swarm/

## Como jogar

| Ação | Controle |
|---|---|
| Mover | `WASD` ou setas (no celular, arraste o dedo) |
| Dash | `Espaço` (recarga de 1,2 s, invencível por um instante) |
| Pausar | `P` |
| Escolher upgrade | `1`, `2`, `3` ou clique |

O tiro é automático no inimigo mais próximo.

## O que tem no jogo

- **Inimigos:** perseguidores, rápidos, tanques, atiradores (mantêm distância), divisores (viram 3 ao morrer) e explosivos.
- **Chefes** a cada minuto, alternando entre um que atira anéis de projéteis e outro que dá investidas.
- **Hordas** que cercam o jogador a cada 35 s.
- **Armas e upgrades:** tiro múltiplo, perfuração, lâminas orbitais, pulso de energia e uma evolução que combina lâminas e pulso.
- **Itens:** cura, ímã de gemas e bomba de tela.
- **Recorde** salvo no navegador.

## Detalhes técnicos

- **Game feel:** aceleração e atrito no movimento, hit stop em mortes grandes, screen shake, flash ao acertar, rastro e zoom no dash, números de dano flutuantes.
- **Spatial hash** (células de 64 px) para colisão tiro-inimigo e separação entre inimigos, em vez de comparar todos com todos.
- **Bloom** feito reduzindo a imagem do canvas em duas escalas e somando de volta com composição aditiva. Funciona em qualquer navegador, sem WebGL.
- **Áudio sintetizado** com Web Audio, sem arquivos de som.
- **Passo de tempo limitado** (`dt` máximo de 50 ms) para a simulação não explodir quando a aba perde foco.

## Estrutura

```
index.html   o jogo inteiro (HTML, CSS e JavaScript em um único arquivo)
README.md    este arquivo
LICENSE      licença MIT
```

## Rodar localmente

```bash
git clone https://github.com/lauradeola/neon-swarm.git
cd neon-swarm
python3 -m http.server 8000
```

Abra `http://localhost:8000`. Também funciona dar dois cliques no `index.html`.

## Próximos passos

- Separar o código em arquivos e migrar para módulos ES (ou TypeScript), com estado encapsulado.
- Separar as regras (dano, XP, spawn) da renderização para poder testá-las.
- Reaproveitar objetos (pooling) para reduzir coleta de lixo.
- Mais armas, chefes e personagens, com meta-progressão entre partidas.
- Bloom e distorção com shaders em WebGL.
- Opção para reduzir tremor de tela e flashes.

## Licença

MIT. Veja `LICENSE`.
