// Upgrades e tipos de inimigo
const U=[['Dano +30%',()=>P.dmg*=1.3],['Cadência +25%',()=>P.rate*=1.25],['Velocidade +15%',()=>P.spd*=1.15],['Tiro extra',()=>P.n++],['Perfuração +1',()=>P.pierce++],['Ímã maior',()=>P.mag*=1.5],['Vida +30',()=>{P.max+=30;P.hp=P.max}],['Lâminas orbitais +1',()=>P.orb++],['Pulso de energia +1',()=>P.nv++]];
const TY=[{r:12,s:70,hp:20,c:'#ff4d6d',d:8},{r:9,s:150,hp:12,c:'#ffb02e',d:6},{r:24,s:50,hp:120,c:'#b06cff',d:16},{r:14,s:45,hp:30,c:'#4dd2ff',d:8,k:'sh'},{r:20,s:55,hp:50,c:'#7cff6b',d:10,k:'sp'},{r:11,s:115,hp:10,c:'#ffd24a',d:0,k:'ex'}];
