// Bloom por downscale + soma aditiva
const b1=document.createElement('canvas'),b2=document.createElement('canvas'),c1=b1.getContext('2d'),c2=b2.getContext('2d');
function bloom(){const w1=W>>2,h1=H>>2,w2=W/10|0,h2=H/10|0;if(b1.width!=w1||b1.height!=h1){b1.width=w1;b1.height=h1;b2.width=w2;b2.height=h2}c1.drawImage(cv,0,0,w1,h1);c2.drawImage(b1,0,0,w2,h2);x.globalCompositeOperation='lighter';x.globalAlpha=.55;x.drawImage(b1,0,0,W,H);x.globalAlpha=.7;x.drawImage(b2,0,0,W,H);x.globalAlpha=1;x.globalCompositeOperation='source-over'}
