// Inicialização e game loop
reset();let lt=performance.now();
(function loop(n){const dt=Math.min(.05,(n-lt)/1000);lt=n;fl=Math.max(0,fl-dt*2);if(hs>0)hs-=dt;else if(st=='play')upd(dt);draw();requestAnimationFrame(loop)})(lt);
