// Simulação: movimento, spawn, armas, colisões, XP, itens
function hurt(d){P.hp-=d;P.inv=.6;shake=14;burst(P.x,P.y,'#ff4d6d',18,260);sfx(110,.3,'sawtooth',.08);if(P.hp<=0){st='dead';best=Math.max(best,T);try{localStorage.setItem('ns',best)}catch(e){}burst(P.x,P.y,'#66ccff',60,400);sfx(80,.8,'sawtooth',.1)}}
function upd(dt){
T+=dt;
let ix=(K.d||K.arrowright?1:0)-(K.a||K.arrowleft?1:0),iy=(K.s||K.arrowdown?1:0)-(K.w||K.arrowup?1:0);
if(joy){ix=joy.dx;iy=joy.dy}
const m=Math.hypot(ix,iy)||1,k=Math.min(1,dt*10);
P.vx+=(ix/m*(ix||iy?P.spd:0)-P.vx)*k;P.vy+=(iy/m*(ix||iy?P.spd:0)-P.vy)*k;
P.cd-=dt;P.inv-=dt;
if(K[' ']&&P.cd<=0){P.cd=1.2;P.inv=.3;const a=ix||iy?Math.atan2(iy,ix):P.ang;P.vx=Math.cos(a)*900;P.vy=Math.sin(a)*900;burst(P.x,P.y,'#66ccff',14,200);sfx(600,.15,'sawtooth');zm=1.15}
P.x+=P.vx*dt;P.y+=P.vy*dt;if(Math.hypot(P.vx,P.vy)>400)tr.push({x:P.x,y:P.y,l:.25});
spT-=dt;
if(spT<=0){spT=Math.max(.12,.9-T*.006);const a=Math.random()*6.28,d=Math.max(W,H)*.6,r=Math.random(),ty=T>60&&r<.06?5:T>45&&r<.14?4:T>30&&r<.22?3:T>40&&r<.3?2:T>15&&r<.5?1:0,D=TY[ty];
E.push({x:P.x+Math.cos(a)*d,y:P.y+Math.sin(a)*d,r:D.r,s:D.s*(1+T*.002),hp:D.hp*(1+T/60),c:D.c,d:D.d,k:D.k,f:0,at:2})}
if(T>=wv){wv+=35;const n=24,d=Math.max(W,H)*.55,t=TY[1];for(let i=0;i<n;i++){const a=i/n*6.283;E.push({x:P.x+Math.cos(a)*d,y:P.y+Math.sin(a)*d,r:t.r,s:t.s*(1+T*.002),hp:t.hp*(1+T/60),c:t.c,d:t.d,f:0})}banner='HORDA!';bt=2;sfx(90,.6,'sawtooth',.08)}
if(T>=nb){nb+=60;const a=Math.random()*6.28,h=1200*(1+T/90);E.push({x:P.x+Math.cos(a)*600,y:P.y+Math.sin(a)*600,r:48,s:45,hp:h,mh:h,c:Math.floor(T/60)%2?'#ff9f1c':'#ff3df2',d:25,f:0,bs:1,v:Math.floor(T/60)%2,at:2});banner='CHEFE!';bt=2;shake=20;sfx(60,1,'sawtooth',.1)}
fT-=dt;let tg=null,bd=1e9;
for(const e of E){const d=(e.x-P.x)**2+(e.y-P.y)**2;if(d<bd){bd=d;tg=e}}
if(tg&&bd<500*500){P.ang=Math.atan2(tg.y-P.y,tg.x-P.x);
if(fT<=0){fT=1/P.rate;for(let i=0;i<P.n;i++){const a=P.ang+(i-(P.n-1)/2)*.18;B.push({x:P.x,y:P.y,vx:Math.cos(a)*700,vy:Math.sin(a)*700,l:1,p:P.pierce,h:[]})}sfx(900,.06,'square',.02);shake=Math.max(shake,1.5)}}
hbuild();for(const b of B){b.x+=b.vx*dt;b.y+=b.vy*dt;b.l-=dt;
near(b.x,b.y,e=>{if(b.l>0&&!b.h.includes(e)&&Math.hypot(e.x-b.x,e.y-b.y)<e.r+4){b.h.push(e);e.hp-=P.dmg;e.f=.08;FT.push({x:e.x,y:e.y-e.r,t:String(Math.round(P.dmg)),l:.6,m:.6});burst(b.x,b.y,'#ffe27a',3,120);sfx(300,.05,'sawtooth',.02);if(b.p--<=0)b.l=0}})}
if(P.nv){P.nt-=dt;if(P.nt<=0){P.nt=Math.max(1.5,4.5-P.nv*.5);const R=140+30*P.nv;for(const e of E)if(Math.hypot(e.x-P.x,e.y-P.y)<R+e.r){e.hp-=P.dmg*2;e.f=.1;FT.push({x:e.x,y:e.y-e.r,t:String(Math.round(P.dmg*2)),l:.6,m:.6})}RG.push({x:P.x,y:P.y,R,l:.4});shake=Math.max(shake,6);sfx(120,.25,'sine',.08)}}
for(const e of E)if(e.bs){e.at-=dt;if(e.at<=0&&e.v){e.at=2.5;e.ch=.7;sfx(200,.4,'sawtooth',.06)}if(e.ch>0)e.ch-=dt;if(e.at<=0&&!e.v){e.at=3;for(let i=0;i<14;i++){const a=i/14*6.283+T;EB.push({x:e.x,y:e.y,vx:Math.cos(a)*200,vy:Math.sin(a)*200,l:4})}sfx(150,.3,'square',.05)}}
if(P.orb)for(const e of E){e.oc=(e.oc||0)-dt;for(let i=0;i<P.orb;i++){const a=T*3+i/P.orb*6.283,qx=P.x+Math.cos(a)*(P.evo?95:60),qy=P.y+Math.sin(a)*(P.evo?95:60);if(e.oc<=0&&Math.hypot(e.x-qx,e.y-qy)<e.r+8){const od=P.dmg*(P.evo?2:.8);e.hp-=od;e.f=.08;e.oc=.3;FT.push({x:e.x,y:e.y-e.r,t:String(Math.round(od)),l:.6,m:.6});burst(qx,qy,'#44ffee',4,120)}}}
for(const e of E){const a=Math.atan2(P.y-e.y,P.x-e.x);let sp=e.s*(e.ch>0?6:1);if(e.k=='sh'){const dd=Math.hypot(P.x-e.x,P.y-e.y);if(dd<240)sp=-sp*.6;else if(dd<320)sp=0;e.at-=dt;if(e.at<=0&&dd<650){e.at=2.2;EB.push({x:e.x,y:e.y,vx:Math.cos(a)*260,vy:Math.sin(a)*260,l:3.5});sfx(500,.1,'square',.03)}}e.x+=Math.cos(a)*sp*dt;e.y+=Math.sin(a)*sp*dt;e.f-=dt;
if(!e.bs)near(e.x,e.y,o=>{if(o!==e){const dx=e.x-o.x,dy=e.y-o.y,d=Math.hypot(dx,dy),m=e.r+o.r;if(d>0&&d<m){e.x+=dx/d*(m-d)*5*dt;e.y+=dy/d*(m-d)*5*dt}}});
if(e.k=='ex'&&Math.hypot(P.x-e.x,P.y-e.y)<e.r+30)e.hp=0;
if(e.k!='ex'&&P.inv<=0&&Math.hypot(P.x-e.x,P.y-e.y)<e.r+12){P.hp-=e.d;P.inv=.6;shake=14;burst(P.x,P.y,'#ff4d6d',18,260);sfx(110,.3,'sawtooth',.08);
if(P.hp<=0){st='dead';best=Math.max(best,T);try{localStorage.setItem('ns',best)}catch(e){}burst(P.x,P.y,'#66ccff',60,400);sfx(80,.8,'sawtooth',.1)}}
if(e.hp<=0){kills++;if(Math.random()<(e.bs?1:.03))IT.push({x:e.x,y:e.y,t:'hmb'[Math.random()*3|0],l:15});if(e.k=='sp')for(let i=0;i<3;i++){const aa=i*2.09+Math.random();E.push({x:e.x+Math.cos(aa)*18,y:e.y+Math.sin(aa)*18,r:8,s:110,hp:8,c:'#7cff6b',d:5,f:0})}if(e.k=='ex'){burst(e.x,e.y,'#ffd24a',30,400);RG.push({x:e.x,y:e.y,R:90,l:.4});if(Math.hypot(P.x-e.x,P.y-e.y)<90&&P.inv<=0)hurt(18)}burst(e.x,e.y,e.c,16,260);shake=Math.max(shake,e.r>20?10:4);if(e.r>20)hs=.06;if(e.bs){hs=.2;shake=30;for(let i=0;i<12;i++)G.push({x:e.x+(Math.random()-.5)*80,y:e.y+(Math.random()-.5)*80,v:3});burst(e.x,e.y,'#ff3df2',80,500);sfx(50,1,'sawtooth',.1)}G.push({x:e.x,y:e.y,v:e.r>20?3:1});sfx(200,.12,'triangle',.04)}}
E=E.filter(e=>e.hp>0);B=B.filter(b=>b.l>0);
for(const b of EB){b.x+=b.vx*dt;b.y+=b.vy*dt;b.l-=dt;if(st=='play'&&P.inv<=0&&Math.hypot(P.x-b.x,P.y-b.y)<16){b.l=0;hurt(10)}}EB=EB.filter(b=>b.l>0);
for(const g of G){const d=Math.hypot(P.x-g.x,P.y-g.y);if(d<P.mag){g.x+=(P.x-g.x)*dt*8;g.y+=(P.y-g.y)*dt*8}
if(d<16){g.v=-g.v;P.xp+=-g.v;sfx(800,.08,'sine',.03)}}
G=G.filter(g=>g.v>0);
for(const it of IT){it.l-=dt;if(Math.hypot(P.x-it.x,P.y-it.y)<22){it.l=0;FT.push({x:P.x,y:P.y-20,t:{h:'+VIDA',m:'ÍMÃ',b:'BOMBA'}[it.t],l:1,m:1});if(it.t=='h')P.hp=Math.min(P.max,P.hp+30);else if(it.t=='m'){for(const g of G){g.x=P.x;g.y=P.y}}else{for(const e of E){if(e.bs)e.hp-=200;else e.hp-=60}RG.push({x:P.x,y:P.y,R:600,l:.5});shake=25;hs=.1}sfx(700,.2,'triangle',.07);burst(P.x,P.y,'#ffffff',20,300)}}IT=IT.filter(i=>i.l>0);
if(P.xp>=P.need){P.xp-=P.need;P.lv++;P.need=Math.round(P.need*1.4+3);opts=[...U].sort(()=>Math.random()-.5).slice(0,3);if(P.orb>1&&P.nv>1&&!P.evo)opts[0]=['EVOLUÇÃO: lâminas de fogo',()=>{P.evo=1;P.dmg*=1.2}];st='lvl';fl=1;sfx(700,.3,'triangle',.07)}
for(const p of PT){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=.96;p.vy*=.96;p.l-=dt}PT=PT.filter(p=>p.l>0);for(const f of FT){f.y-=40*dt;f.l-=dt}for(const g of RG)g.l-=dt;RG=RG.filter(g=>g.l>0);bt-=dt;FT=FT.filter(f=>f.l>0);for(const t of tr)t.l-=dt;tr=tr.filter(t=>t.l>0);zm+=(1-zm)*Math.min(1,dt*5);
cam.x+=(P.x-cam.x)*Math.min(1,dt*6);cam.y+=(P.y-cam.y)*Math.min(1,dt*6);shake*=Math.pow(.01,dt)}
