// Reset, início de partida, partículas e escolha de upgrade
function reset(){P={x:0,y:0,vx:0,vy:0,hp:100,max:100,xp:0,lv:1,need:5,cd:0,inv:0,orb:0,nv:0,nt:0,dmg:10,rate:3,spd:260,n:1,pierce:0,mag:90,ang:0};E=[];B=[];G=[];PT=[];FT=[];tr=[];EB=[];RG=[];IT=[];nb=45;wv=25;bt=0;hs=0;zm=1;fl=0;T=0;kills=0;cam={x:0,y:0};shake=0;spT=0;fT=0}
function start(){reset();st='play';ac()}
function burst(px,py,c,n,s){for(let i=0;i<n;i++){const a=Math.random()*6.28,v=s*(.3+Math.random());PT.push({x:px,y:py,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:.5+Math.random()*.4,m:.9,c})}}
function pick(i){if(!opts[i])return;opts[i][1]();st='play';sfx(500,.2,'triangle',.06)}
