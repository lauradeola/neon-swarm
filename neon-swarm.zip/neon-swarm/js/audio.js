// Efeitos sonoros sintetizados (Web Audio)
function ac(){A=A||new(window.AudioContext||window.webkitAudioContext)()}
function sfx(f,d,t='square',v=.04){if(!A)return;const o=A.createOscillator(),g=A.createGain(),n=A.currentTime;o.type=t;o.frequency.setValueAtTime(f,n);o.frequency.exponentialRampToValueAtTime(f/2,n+d);g.gain.setValueAtTime(v,n);g.gain.exponentialRampToValueAtTime(.001,n+d);o.connect(g).connect(A.destination);o.start();o.stop(n+d)}
