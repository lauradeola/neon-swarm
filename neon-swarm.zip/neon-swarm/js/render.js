// Renderização, HUD e telas
function orb(px,py,r,c,a=1){x.globalAlpha=.22*a;x.fillStyle=c;x.beginPath();x.arc(px,py,r*2.4,0,6.28);x.fill();x.globalAlpha=a;x.beginPath();x.arc(px,py,r,0,6.28);x.fill()}
function tx(s,px,py,sz,c,al='center'){x.font=sz+'px system-ui,sans-serif';x.textAlign=al;x.fillStyle=c;x.fillText(s,px,py)}
function draw(){
x.setTransform(1,0,0,1,0,0);x.globalAlpha=1;x.globalCompositeOperation='source-over';x.fillStyle='#07070f';x.fillRect(0,0,W,H);
const ox=W/2-cam.x+(Math.random()-.5)*shake,oy=H/2-cam.y+(Math.random()-.5)*shake,g=80;
x.strokeStyle='rgba(120,140,255,.09)';x.lineWidth=1;x.beginPath();
for(let a=((ox%g)+g)%g;a<W;a+=g){x.moveTo(a,0);x.lineTo(a,H)}for(let a=((oy%g)+g)%g;a<H;a+=g){x.moveTo(0,a);x.lineTo(W,a)}x.stroke();
x.translate(W/2,H/2);x.scale(zm,zm);x.translate(ox-W/2,oy-H/2);x.globalCompositeOperation='lighter';
for(const q of G)orb(q.x,q.y,4,'#44ffee');
for(const it of IT){const c={h:'#6bff8a',m:'#44ccff',b:'#ff7a45'}[it.t];orb(it.x,it.y,9+Math.sin(T*6)*1.5,c,it.l<3&&Math.floor(T*8)%2?.3:1)}
for(const t of tr)orb(t.x,t.y,10*t.l/.25,'#55ccff',t.l/.25*.6);
for(const e of E){const c=e.f>0?'#ffffff':e.c,r=e.r*(1+Math.sin(T*8+e.x)*.08),rot=T*(e.r>20?1:3)+e.x,n=e.bs?8:e.k=='sh'?5:e.k=='sp'?7:e.k=='ex'?3:e.r>20?6:e.r<10?3:4;orb(e.x,e.y,r*.6,c,.5);x.globalAlpha=1;x.strokeStyle=c;x.lineWidth=2;x.beginPath();for(let i=0;i<=n;i++){const a=rot+i/n*6.283;x[i?'lineTo':'moveTo'](e.x+Math.cos(a)*r,e.y+Math.sin(a)*r)}x.stroke()}
for(const b of B)orb(b.x,b.y,4,'#ffe27a');
for(const b of EB)orb(b.x,b.y,5,'#ff3df2');
for(const p of PT)orb(p.x,p.y,2.5,p.c,Math.max(0,p.l/p.m));
for(const g of RG){x.globalAlpha=Math.max(0,g.l/.4);x.strokeStyle='#ffd24a';x.lineWidth=4;x.beginPath();x.arc(g.x,g.y,g.R*(1-g.l/.4),0,6.283);x.stroke()}
for(const f of FT){x.globalAlpha=Math.max(0,f.l/f.m);tx(f.t,f.x,f.y,13,'#ffffff')}
for(let i=0;i<P.orb;i++){const a=T*3+i/P.orb*6.283;orb(P.x+Math.cos(a)*(P.evo?95:60),P.y+Math.sin(a)*(P.evo?95:60),P.evo?10:7,P.evo?'#ff8a3d':'#44ffee')}
if(st!='dead'){orb(P.x,P.y,12,P.inv>0?'#ffffff':'#55ccff');x.globalAlpha=.7;x.strokeStyle='#55ccff';x.lineWidth=2;x.beginPath();x.moveTo(P.x+Math.cos(P.ang)*16,P.y+Math.sin(P.ang)*16);x.lineTo(P.x+Math.cos(P.ang)*26,P.y+Math.sin(P.ang)*26);x.stroke()}
x.setTransform(1,0,0,1,0,0);x.globalAlpha=1;x.globalCompositeOperation='source-over';
bloom();const v=x.createRadialGradient(W/2,H/2,Math.min(W,H)*.35,W/2,H/2,Math.max(W,H)*.75);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(0,0,0,.55)');x.fillStyle=v;x.fillRect(0,0,W,H);
if(fl>0){x.fillStyle='rgba(68,255,238,'+fl*.35+')';x.fillRect(0,0,W,H)}
if(st=='menu')return ov('NEON SWARM','Mova: WASD ou setas · Dash: espaço · Atira sozinho','Clique ou Enter para jogar');
x.fillStyle='rgba(255,255,255,.12)';x.fillRect(16,16,200,10);x.fillStyle='#ff4d6d';x.fillRect(16,16,200*Math.max(0,P.hp/P.max),10);
x.fillStyle='rgba(255,255,255,.12)';x.fillRect(16,32,200,6);x.fillStyle='#44ffee';x.fillRect(16,32,200*P.xp/P.need,6);
tx('Nível '+P.lv+' · '+kills+' abates',16,60,13,'#cfd3ff','left');
const bo=E.find(e=>e.bs);if(bo){x.fillStyle='rgba(255,255,255,.12)';x.fillRect(W/2-150,16,300,8);x.fillStyle='#ff3df2';x.fillRect(W/2-150,16,300*Math.max(0,bo.hp/bo.mh),8);tx('CHEFE',W/2,42,12,'#ff3df2')}
if(bt>0)tx(banner,W/2,H/2-120,34,'#ffb02e');
const s=Math.floor(T);tx(Math.floor(s/60)+':'+String(s%60).padStart(2,'0'),W-16,28,20,'#fff','right');
tx(P.cd<=0?'DASH pronto':'dash '+P.cd.toFixed(1)+'s',W-16,48,12,P.cd<=0?'#66ccff':'#778','right');
if(st=='pause')ov('PAUSADO','Pressione P para continuar','');
if(st=='dead')ov('FIM DE JOGO','Você sobreviveu '+s+'s com '+kills+' abates · recorde '+Math.floor(best)+'s','Clique ou Enter para tentar de novo');
if(st=='lvl'){x.fillStyle='rgba(0,0,0,.65)';x.fillRect(0,0,W,H);tx('SUBIU DE NÍVEL',W/2,H/2-110,24,'#44ffee');
opts.forEach((o,i)=>{const cx=W/2+(i-1)*230;x.strokeStyle='#44ffee';x.lineWidth=1.5;x.strokeRect(cx-100,H/2-70,200,120);tx(String(i+1),cx,H/2-38,14,'#778');tx(o[0],cx,H/2,16,'#fff')})}}
function ov(a,b,c){x.fillStyle='rgba(0,0,0,.6)';x.fillRect(0,0,W,H);tx(a,W/2,H/2-30,Math.min(52,W/9),'#55ccff');tx(b,W/2,H/2+10,15,'#cfd3ff');tx(c,W/2,H/2+44,14,'#778')}
