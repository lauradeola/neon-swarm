// Teclado, mouse e toque
onkeydown=e=>{const k=e.key.toLowerCase();K[k]=1;if(k==' ')e.preventDefault();if((st=='menu'||st=='dead')&&(k=='enter'||k==' '))start();if(st=='lvl'&&'123'.includes(k))pick(+k-1);if(k=='p'&&(st=='play'||st=='pause'))st=st=='play'?'pause':'play'};
onkeyup=e=>K[e.key.toLowerCase()]=0;
cv.onpointerdown=e=>{if(st=='menu'||st=='dead')return start();if(st=='lvl'){const i=Math.round((e.clientX-W/2)/230)+1;if(Math.abs(e.clientX-(W/2+(i-1)*230))<100&&Math.abs(e.clientY-H/2+10)<60)pick(i)}else joy={sx:e.clientX,sy:e.clientY,dx:0,dy:0}};
cv.onpointermove=e=>{if(joy){const dx=e.clientX-joy.sx,dy=e.clientY-joy.sy,d=Math.hypot(dx,dy);joy.dx=d>10?dx/Math.max(d,40):0;joy.dy=d>10?dy/Math.max(d,40):0}};
onpointerup=()=>joy=null;
