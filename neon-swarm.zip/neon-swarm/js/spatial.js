// Spatial hash para colisões
const HG=new Map(),hk=(i,j)=>(i*73856093)^(j*19349663);
function hbuild(){HG.clear();for(const e of E){const k=hk(Math.floor(e.x/64),Math.floor(e.y/64));let a=HG.get(k);if(!a)HG.set(k,a=[]);a.push(e)}}
function near(px,py,f){const cx=Math.floor(px/64),cy=Math.floor(py/64);for(let i=-1;i<=1;i++)for(let j=-1;j<=1;j++){const a=HG.get(hk(cx+i,cy+j));if(a)for(const e of a)f(e)}}
