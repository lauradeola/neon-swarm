// Canvas, estado global e teclado
const cv=document.getElementById('c'),x=cv.getContext('2d');let W,H;
function rs(){W=cv.width=innerWidth;H=cv.height=innerHeight}onresize=rs;rs();
let st='menu',P,E,B,G,PT,T,kills,cam,shake,spT,fT,opts=[],best=+(()=>{try{return localStorage.getItem('ns')}catch(e){return 0}})()||0,A,joy=null,FT=[],tr=[],hs=0,zm=1,fl=0,EB=[],nb=45,RG=[],wv=25,banner='',bt=0,IT=[];
const K={};
